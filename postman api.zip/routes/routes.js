const router = require("express").Router()
const stucontroller = require("../api/studentController") 

router.post("/addstudent",stucontroller.addStu)
router.post("/showstudent",stucontroller.showstu)
router.post("/showone",stucontroller.showone)
module.exports = router